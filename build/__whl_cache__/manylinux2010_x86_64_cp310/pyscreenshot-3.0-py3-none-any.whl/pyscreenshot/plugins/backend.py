UNKNOWN_VERSION = "?.?"


class CBackend(object):
    is_subprocess = False
